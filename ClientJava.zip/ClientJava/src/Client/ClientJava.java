/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Client;

import javax.swing.JTextArea;

/**
 *
 * @author Farhan
 */
public class ClientJava {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        ClientFrame frame=new ClientFrame(); 
        frame.setTitle("CLIENT");
        frame.setBounds(500, 10, 320, 320);
        frame.setVisible(true);
        frame.setDefaultCloseOperation(3);
        
        
        
    }
    
}
